# GameOn

Videos juegos

Comisión 24111 Team 10

Nuestro equipo diseña una primera web con temática de Video Games
Trabajamos con Javascript para validar campos y consumir una API de juegos alojados en https://api.rawg.io/api/games
al que tuvimos que suscribirnos para tener una APIKEY
Finalmente conectamos con un Back-End en Java via Servlets en un server Tomcat, para registrar usuarios
en la base de datos MySQ y validar un login de administrador para mostrar/modificar
y eliminar una lista de usuarios registrados mediante la opción Registrarse.

Entre los archivos encontraran:
gameon.sql => script para crear la base de datos gameon y sus tablas login y registrosusuarios
GameOn.zip => proyecto de Netbeans para importar en formato .zip
GameOn.mp4 => video de funcionamiento del programa

Link del video en YouTube: https://youtu.be/wrGGNlD_gbk