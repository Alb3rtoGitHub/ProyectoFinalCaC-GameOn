# GameOn

Videos juegos Team 10

Pertenecemos a la comision 24111

TEAM 10:
Candelaria Marchisone
Martin Sebastian Schipani
Denis Daniel Silva
Alberto Vallecillo

Nuestro equipo diseña una primera web con temática de Video Games
Trabajamos con Javascript para validar campos y consumir una API de películas
alojadas en TMDB
Finalmente conectamos con un Back-End en Java via Servlets en un server Tomcat, para registrar usuarios
en la base de datos MySQ y validar un login de administrador para mostrar/modificar
y eliminar usuarios.
